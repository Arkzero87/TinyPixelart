
 NINTENDO Logo Re-drawn to pixel level by arkzero.
 
 * For those Wanting a retro look but w/ higher quality.
 
 All logos are 256*256px, indexed 4-color palette PNGs, making extra-easy for you to edit the palette to your heart's content. No longer need to guess which color goes where, or being color-picking every shade to check for the correct tone. These re-drawns will look clean and sharp at way higher resolutions than GBA was ever capable to handle. You can run your emulator at fullscreen with no filters applied and notice little to none quality loss. Yet each logo is as light as possible (less than 1kb each).

 These files are distributed under MIT license.